$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Online_MM/features/CAN_Online_TC08_EPP_Existing_Etransfer.feature");
formatter.feature({
  "comments": [
    {
      "line": 1,
      "value": "##scenario: Test case 60291: TS_12_Online_Existing_Customer_EPP_Approved_E_Transfer_Paid early from online"
    }
  ],
  "line": 3,
  "name": "Online_Existing Customer_EPP_Approved",
  "description": "",
  "id": "online-existing-customer-epp-approved",
  "keyword": "Feature"
});
formatter.before({
  "duration": 3249842800,
  "status": "passed"
});
formatter.scenario({
  "line": 6,
  "name": "Online_Existing Customer_EPP_Approved|TC_08_Existing_EPP",
  "description": "",
  "id": "online-existing-customer-epp-approved;online-existing-customer-epp-approved|tc-08-existing-epp",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 5,
      "name": "@EPPApproved"
    }
  ]
});
formatter.step({
  "line": 7,
  "name": "Genareted sin",
  "keyword": "Given "
});
formatter.step({
  "line": 8,
  "name": "user click on signup customer",
  "keyword": "Given "
});
formatter.step({
  "line": 9,
  "name": "Pre-requisite data generation for customer",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "verify the phonenumber threshold",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 11,
      "value": "#And Verify the address threshold and update address"
    }
  ],
  "line": 12,
  "name": "Create customer",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "Run the TU query",
  "keyword": "And "
});
formatter.step({
  "line": 14,
  "name": "customer chooses SPL loan",
  "keyword": "And "
});
formatter.step({
  "line": 15,
  "name": "User provides basic information for spl",
  "keyword": "And "
});
formatter.step({
  "line": 16,
  "name": "Provides income information",
  "keyword": "And "
});
formatter.step({
  "line": 17,
  "name": "signed the picra and submit application",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "enter valid OTP",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 19,
      "value": "# And select the funding types"
    }
  ],
  "line": 20,
  "name": "add the bank details",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "upload document",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "verify the loan status and update loan status in DB",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "click on Finalize and e-Sign Loan Documents",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 24,
      "value": "# And Loan approval screen  no need"
    }
  ],
  "line": 25,
  "name": "Loan approved final offer",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "funding and payment confirmation EPP",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "esing document and back to dashboard",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 28,
      "value": "##Back date the loan and make a payment"
    }
  ],
  "line": 29,
  "name": "Backdate loan and get make a payment button",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "make a SPL payment",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "Backdate loan and get make a payment button",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 32,
      "value": "##update the loan contract"
    }
  ],
  "line": 33,
  "name": "update loan contract",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 35,
      "value": "## completed"
    }
  ],
  "line": 36,
  "name": "sign the customer",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "customer chooses SPL loan",
  "keyword": "And "
});
formatter.step({
  "line": 39,
  "name": "verify the existing customer details for SPL",
  "keyword": "And "
});
formatter.step({
  "line": 41,
  "name": "Provides income information",
  "keyword": "And "
});
formatter.step({
  "line": 42,
  "name": "signed the picra and submit application",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 43,
      "value": "#And  enter valid OTP  no need"
    }
  ],
  "line": 44,
  "name": "change the funding types",
  "keyword": "And "
});
formatter.step({
  "line": 45,
  "name": "add the bank details",
  "keyword": "And "
});
formatter.step({
  "line": 46,
  "name": "upload document",
  "keyword": "And "
});
formatter.step({
  "line": 47,
  "name": "verify the loan status and update loan status in DB",
  "keyword": "And "
});
formatter.step({
  "line": 48,
  "name": "click on Finalize and e-Sign Loan Documents",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 49,
      "value": "#And Loan approval screen  no need"
    }
  ],
  "line": 50,
  "name": "Loan approved final offer",
  "keyword": "And "
});
formatter.step({
  "line": 51,
  "name": "funding and payment confirmation EPP",
  "keyword": "And "
});
formatter.step({
  "line": 52,
  "name": "esing document and back to dashboard",
  "keyword": "And "
});
formatter.step({
  "comments": [
    {
      "line": 55,
      "value": "#############"
    },
    {
      "line": 56,
      "value": "## Approved the loan from strom"
    },
    {
      "line": 58,
      "value": "###log file"
    }
  ],
  "line": 59,
  "name": "Initialize Loan Details and write to excel",
  "keyword": "And "
});
formatter.step({
  "line": 60,
  "name": "log all the Loan details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 61,
  "name": "log all the Note details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 62,
  "name": "log all payment details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 63,
  "name": "log all Transaction details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 64,
  "name": "log all EFTLog details in logger for investigation",
  "keyword": "And "
});
formatter.step({
  "line": 65,
  "name": "log all ETransferLog details in logger for investigation",
  "keyword": "And "
});
formatter.match({
  "location": "random_generate.genareted_sin()"
});
formatter.embedding("image/png", "embedded0.png");
formatter.embedding("image/png", "embedded1.png");
formatter.result({
  "duration": 30857111100,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.user_click_on_signup_customer()"
});
formatter.embedding("image/png", "embedded2.png");
formatter.embedding("image/png", "embedded3.png");
formatter.embedding("image/png", "embedded4.png");
formatter.result({
  "duration": 21595176800,
  "status": "passed"
});
formatter.match({
  "location": "random_generate.create_customerpre_requisite_data_generation()"
});
formatter.result({
  "duration": 4837208800,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.verify_the_phonenumber_threshold()"
});
formatter.result({
  "duration": 9399465100,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.create_customer()"
});
formatter.embedding("image/png", "embedded5.png");
formatter.embedding("image/png", "embedded6.png");
formatter.embedding("image/png", "embedded7.png");
formatter.result({
  "duration": 25057783100,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.run_the_TU_query()"
});
formatter.result({
  "duration": 8437374400,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.customer_chooses_SPL_loan()"
});
formatter.embedding("image/png", "embedded8.png");
formatter.result({
  "duration": 7305656700,
  "status": "passed"
});
formatter.match({
  "location": "SPLLoandenied.user_provides_basic_information_for_spl()"
});
formatter.embedding("image/png", "embedded9.png");
formatter.result({
  "duration": 40035868000,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.provides_income_information()"
});
formatter.embedding("image/png", "embedded10.png");
formatter.embedding("image/png", "embedded11.png");
formatter.embedding("image/png", "embedded12.png");
formatter.embedding("image/png", "embedded13.png");
formatter.result({
  "duration": 27143751600,
  "status": "passed"
});
formatter.match({
  "location": "ILLoandenied.signed_the_picra_and_submit_application()"
});
formatter.embedding("image/png", "embedded14.png");
formatter.embedding("image/png", "embedded15.png");
formatter.result({
  "duration": 19500997300,
  "status": "passed"
});
formatter.match({
  "location": "TC37_autovoid_esignpending.enter_valid_OTP()"
});
formatter.embedding("image/png", "embedded16.png");
formatter.embedding("image/png", "embedded17.png");
formatter.result({
  "duration": 83532510600,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.add_the_bank_details()"
});
formatter.embedding("image/png", "embedded18.png");
formatter.result({
  "duration": 10257599700,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.upload_document()"
});
formatter.embedding("image/png", "embedded19.png");
formatter.embedding("image/png", "embedded20.png");
formatter.result({
  "duration": 16113587900,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_status_and_update_loan_status_in_DB()"
});
formatter.result({
  "duration": 4674278400,
  "status": "passed"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.click_on_Finalize_and_e_Sign_Loan_Documents()"
});
formatter.embedding("image/png", "embedded21.png");
formatter.embedding("image/png", "embedded22.png");
formatter.embedding("image/png", "embedded23.png");
formatter.result({
  "duration": 24255815800,
  "status": "passed"
});
formatter.match({
  "location": "TC23_EPP_Cross_Sell.loan_approved_final_offer()"
});
formatter.embedding("image/png", "embedded24.png");
formatter.result({
  "duration": 19547973700,
  "status": "passed"
});
formatter.match({
  "location": "TC06_EPP_approved.funding_and_payment_confirmation_EPP()"
});
formatter.result({
  "duration": 12892348900,
  "error_message": "java.lang.AssertionError: WebDriverException : WHILE TRYING TO CLICK ON THE SPECIFIED WEB ELEMENTUser_unable_to_click_on_the_\u003cb\u003eNext button\u003c/b\u003e_due_to_the_Exception:-element click intercepted: Element \u003cbutton form\u003d\"offer-form\" class\u003d\"mm-btn mm-btn--lg\" data-loading\u003d\"true\" disabled\u003d\"\"\u003e...\u003c/button\u003e is not clickable at point (623, 538). Other element would receive the click: \u003cdiv class\u003d\"mm-page-loader\" role\u003d\"progressbar\"\u003e...\u003c/div\u003e\n  (Session info: chrome\u003d107.0.5304.122)\nBuild info: version: \u00273.5.3\u0027, revision: \u0027a88d25fe6b\u0027, time: \u00272017-08-29T12:42:44.417Z\u0027\nSystem info: host: \u0027QAVDIWIN10-39\u0027, ip: \u002710.220.111.95\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u00271.8.0_321\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities [{networkConnectionEnabled\u003dfalse, chrome\u003d{chromedriverVersion\u003d106.0.5249.61 (511755355844955cd3e264779baf0dd38212a4d0-refs/branch-heads/5249@{#569}), userDataDir\u003dC:\\Users\\91434\\AppData\\Local\\Temp\\scoped_dir21996_1838636449}, timeouts\u003d{implicit\u003d0, pageLoad\u003d300000, script\u003d30000}, pageLoadStrategy\u003dnone, unhandledPromptBehavior\u003ddismiss and notify, strictFileInteractability\u003dfalse, platform\u003dXP, proxy\u003dProxy(), goog:chromeOptions\u003d{debuggerAddress\u003dlocalhost:61654}, webauthn:extension:credBlob\u003dtrue, acceptInsecureCerts\u003dfalse, browserVersion\u003d107.0.5304.122, browserName\u003dchrome, javascriptEnabled\u003dtrue, platformName\u003dXP, setWindowRect\u003dtrue, webauthn:extension:largeBlob\u003dtrue, webauthn:virtualAuthenticators\u003dtrue}]\nSession ID: 41b7b26ee25aba2c52393f5612cd4fc3\r\n\tat org.testng.Assert.fail(Assert.java:97)\r\n\tat actions.OnlineActions.click(OnlineActions.java:321)\r\n\tat pages.Pg_15_fundingPaymentConfirmation.fundingPaymentConfirmation(Pg_15_fundingPaymentConfirmation.java:59)\r\n\tat online.StepDefinitions.TC06_EPP_approved.funding_and_payment_confirmation_EPP(TC06_EPP_approved.java:27)\r\n\tat ✽.And funding and payment confirmation EPP(C:/Online_MM/features/CAN_Online_TC08_EPP_Existing_Etransfer.feature:26)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "TC23_EPP_Cross_Sell.esing_document_and_back_to_dashboard()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC33_Reloan.backdate_loan_and_get_make_a_payment_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC31_Engaged_Existing_IL.make_a_SPL_payment()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC33_Reloan.backdate_loan_and_get_make_a_payment_button()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC53_Refinance_withdraw.update_loan_contract()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC44_Refinance_Loan_flinks_out.sign_the_customer()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "SPLLoandenied.customer_chooses_SPL_loan()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC31_Engaged_Existing_IL.verify_the_existing_customer_details_for_SPL()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.provides_income_information()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "ILLoandenied.signed_the_picra_and_submit_application()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC31_Engaged_Existing_IL.change_the_funding_types()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.add_the_bank_details()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.upload_document()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.verify_the_loan_status_and_update_loan_status_in_DB()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC01_ILLoanApproved_Review.click_on_Finalize_and_e_Sign_Loan_Documents()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC23_EPP_Cross_Sell.loan_approved_final_offer()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC06_EPP_approved.funding_and_payment_confirmation_EPP()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "TC23_EPP_Cross_Sell.esing_document_and_back_to_dashboard()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.Initialize_Loan_Details_and_write_to_excel()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Loan_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_the_Note_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_payment_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_Transaction_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_EFTLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "schedulerandDBlog.log_all_ETransferLog_details_in_logger_for_investigation_before_strom()"
});
formatter.result({
  "status": "skipped"
});
formatter.embedding("image/png", "embedded25.png");
formatter.after({
  "duration": 3871813400,
  "status": "passed"
});
});